https://dtc42uawvptv6.cloudfront.net/

NOTE: Perhaps, next time I'll get to customize my website instead of using the default starter file images.
Many thanks!