Distribution Domain name
https://dtc42uawvptv6.cloudfront.net/

My Static Project Bucket website endpoint
http://my-rule2-bucket.s3-website.us-east-2.amazonaws


NOTE: Perhaps, next time I'll get to customize my website instead of using the default starter file images.
Many thanks!

Please find attached Website endpoint URL above. I had it in my github readme.md on first submission.
I'll also update my README file using the Sample Template as suggested. 

All required screenshots are not attached and pushed to github.

Many thanks